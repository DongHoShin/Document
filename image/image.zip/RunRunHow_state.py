import LarvaRun_Framework
import LarvaRunTitle_state
from pico2d import *

name = "HowState"
HowImage = None
backImage = None
yellowLarvaImage = None
MouseX, MouseY = 0,0
startTime = 0.0
frame = 0


class HowCharacter:
    PIXEL_PER_METER = (10.0 / 0.3)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 40.0                   # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.8
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    def __init__(self, color, maxFrame, imageX, imageY, width, height, image):
        self.name = color
        self.maxFrame = maxFrame
        self.frame = 0
        self.imageX = imageX
        self.imageY = imageY
        self.width = width
        self.height =height
        self.dir = 1
        self.image = image
        self.total_frames = 0.0
        self.holdTime =0.0
        self.newTime = 0.0
        self.distance= 0
        self.left = False
        self.right = False
    def update(self, frame_time):
        self.newTime =  get_time()-(self.holdTime + startTime)
        self.distance = HowCharacter.RUN_SPEED_PPS * frame_time
        self.total_frames += HowCharacter.FRAMES_PER_ACTION * HowCharacter.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % self.maxFrame
        self.move()
    def move(self):
        if self.left == True:
            if self.imageX <= 1200:
                self.imageX -= self.distance
        elif self.right == True:
            if self.imageX >= 0:
                self.imageX += self.distance

    def draw(self):
        self.image.clip_draw(self.frame * self.width, 0, self.width, self.height, self.imageX, self.imageY, 100,100)



#//////////////////////////////////////////////////////////////////////////////////////////////////////////
class HowIcons:
    RUN_SPEED_KMPH = 40.0                   # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)

    TIME_PER_ACTION = 0.8
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    def __init__(self, name, maxFrame, imageX, imageY, width, height, image, sizeX, sizeY):
        self.name = name
        self.maxFrame = maxFrame
        self.frame = 0
        self.imageX = imageX
        self.imageY = imageY
        self.width = width
        self.height =height
        self.sizeX = sizeX
        self.sizeY = sizeY
        self.dir = 1
        self.image = image
        self.total_frames = 0.0
        self.holdTime =0.0
        self.newTime = 0.0
    def update(self, frame_time):
        self.newTime =  get_time()-(self.holdTime + startTime)
        self.total_frames += HowIcons.FRAMES_PER_ACTION * HowIcons.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % self.maxFrame
    def draw(self):
        self.image.clip_draw(self.frame * self.width, 0, self.width, self.height, self.imageX, self.imageY, self.sizeX, self.sizeY)
#//////////////////////////////////////////////////////////////////////////////////////////////////////////
def enter():
    global HowImage, backImage, yellowLarvaImage, yellowLarvaHow, backIcon
    HowImage = load_image('HowImage.png')
    backImage = load_image('BackIcon.png')
    yellowLarvaImage = load_image('YlarvaRun.png')

    yellowLarvaHow = HowCharacter('red', 5, 100, 200, 90, 90, yellowLarvaImage)
    backIcon = HowIcons('back', 10, 50, 750, 66, 44, backImage, 100, 80)


def exit():
    global HowImage, backImage, yellowLarvaImage
    del(HowImage)
    del(backImage)
    del(yellowLarvaImage)


def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    global MouseX, MouseY, yellowLarvaHow
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            LarvaRun_Framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                LarvaRun_Framework.quit()
            if event.type == SDL_MOUSEMOTION:
                MouseX,MouseY = event.x,800-event.y
            if (event.type, event.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
                if (0<=MouseX<=200 and 650<=MouseY<=800):
                    LarvaRun_Framework.pop_state()
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
                yellowLarvaHow.left = True
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
                yellowLarvaHow.right = True
            if (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
                yellowLarvaHow.left = False
            if (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
                yellowLarvaHow.right = False



def update(frame_time):
    global frame, yellowLarvaHow, backIcon
    backIcon.update(frame_time)
    yellowLarvaHow.update(frame_time)
    #delay(0.1)


def draw(frame_time):
    global HowImage, backImage, frame, yellowLarvaHow, backIcon
    clear_canvas()
    HowImage.draw(600, 400, 1200, 800)
    backIcon.draw()
    yellowLarvaHow.draw()
    update_canvas()
