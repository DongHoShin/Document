import random
import LarvaRun_Framework
import LarvaRunRank_state
from pico2d import *



yellow = None
stage = None
trapManager = None
itemManager = None
life = None
frame = 0
stageNum = 1
TrapList = []
ItemList = []
rotation = 0
#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Map:
    global stageNum,yellow, rotation
    def __init__(self):
        self.bkframe = 0
        self.doubleX = 600
        self.doubleY = 400
        self.groundX = 600
        self.groundY = 0
        self.groundH = 0

        self.background = None
        self.doublebackground = None
        self.stageOneBackground = None
        self.stageTwoBackground = None
        self.stageThreeBackground = None
        self.stageFourBackground = None
        self.stageOnedoublebackground = None
        self.stageTwodoublebackground = None
        self.stageThreedoublebackground = None
        self.stageFourdoublebackground = None
        self.stageOneGround = None
        self.stageTwoGround = None
        self.stageThreeGround = None
        self.stageFourGround = None
        self.SetStageImage()
    def LoadStageImage(self):
        self.stageOneBackground = load_image('background1.png')
        self.stageTwoBackground = load_image('background2.png')
        self.stageThreeBackground = load_image('background3.png')
        self.stageFourBackground = load_image('background4.png')
        self.stageOnedoublebackground = load_image('doublebackground1.png')
        self.stageTwodoublebackground = load_image('doublebackground2.png')
        self.stageThreedoublebackground = load_image('doublebackground3.png')
        self.stageFourdoublebackground = load_image('doublebackground4.png')
        self.stageOneGround = load_image('ground1.png')
        self.stageTwoGround = load_image('ground2.png')
        self.stageThreeGround = load_image('grass.png')
        self.stageFourGround = load_image('ground4.png')
        print('loadmap')
    def SetStageImage(self):
        if stageNum == 1:
            self.background = self.stageOneBackground
            self.doublebackground = self.stageOnedoublebackground
            self.ground = self.stageOneGround
            self.groundY, self.groundH = 30, 240
        elif stageNum == 2:
            self.background = self.stageTwoBackground
            self.doublebackground = self.stageTwodoublebackground
            self.ground = self.stageTwoGround
            self.groundY, self.groundH = 30, 240
        elif stageNum == 3:
            self.background = self.stageThreeBackground
            self.doublebackground = self.stageThreedoublebackground
            self.ground = self.stageThreeGround
            self.groundY, self.groundH = 600, 1200
        elif stageNum == 4:
            self.background = self.stageFourBackground
            self.doublebackground = self.stageFourdoublebackground
            self.ground = self.stageFourGround
            self.groundY, self.groundH = 70, 130
    def rotatePos(self):
        if stageNum == 1:
            self.doubleX, self.doubleY = self.doubleY, self.doubleX
    def update(self):
        if stageNum == 1:
           self.doubleX -= 5
           if self.doubleX <= -600:
               self.doubleX = 600
           self.groundX -= 20
           if self.groundX <= -600:
                self.groundX = 600
        elif stageNum == 2:
           self.doubleX -= 5
           if self.doubleX <= -600:
               self.doubleX = 600
           self.groundX -= 20
           if self.groundX <= -600:
                self.groundX = 600
        elif stageNum == 3:
           self.doubleX += 35
           if self.doubleX >= 1800:
               self.doubleX = 600
           self.groundX += 20
           if self.groundX >= 1800:
                self.groundX = 600
        elif stageNum == 4:
           self.doubleX += 35
           if self.doubleX >= 1800:
               self.doubleX = 600
           self.groundX += 20
           if self.groundX >= 1800:
                self.groundX = 600

    def draw(self):
        if stageNum == 1:
            self.doublebackground.rotate_draw(rotation, self.doubleX, self.doubleY, 1200, 800)
            self.doublebackground.rotate_draw(rotation, self.doubleX+1200, self.doubleY, 1200, 800)
            self.background.rotate_draw(rotation, self.groundX, self.doubleY, 1200, 800)
            self.background.rotate_draw(rotation, self.groundX+1200, self.doubleY, 1200, 800)
            self.ground.rotate_draw(rotation, self.groundX, self.groundY, 1200, self.groundH)
            self.ground.rotate_draw(rotation, self.groundX+1200, self.groundY, 1200, self.groundH)
        elif stageNum == 2:
            self.doublebackground.rotate_draw(rotation, 600,self.doubleX, 1200, 1200)
            self.doublebackground.rotate_draw(rotation, 600,self.doubleX+1200, 1200, 1200)
            self.background.rotate_draw(rotation, 700, self.groundX, 1200, 1200)
            self.background.rotate_draw(rotation, 700, self.groundX+1200, 1200, 1200)
            self.ground.rotate_draw(rotation, 1160, self.groundX, 1200, 220)
            self.ground.rotate_draw(rotation, 1160, self.groundX+1200, 1200, 220)
        elif stageNum == 3:
            self.doublebackground.rotate_draw(rotation, self.doubleX, 400, 1200, 800)
            self.doublebackground.rotate_draw(rotation, self.doubleX-1200, 400, 1200, 800)
            self.background.rotate_draw(rotation, self.groundX, 400, 1200, 800)
            self.background.rotate_draw(rotation, self.groundX-1200, 400, 1200, 800)
            self.ground.rotate_draw(rotation, self.groundX, 200, 1200, 1200)
            self.ground.rotate_draw(rotation, self.groundX-1200, 200, 1200, 1200)
        elif stageNum == 4:
            self.doublebackground.rotate_draw(rotation,  600,self.doubleX,  1200, 1200)
            self.doublebackground.rotate_draw(rotation, 600, self.doubleX-1200, 1200, 1200)
            self.background.rotate_draw(rotation, 500, self.groundX,  1200, 1200)
            self.background.rotate_draw(rotation, 500, self.groundX-1200,  1200, 1200)
            self.ground.rotate_draw(rotation, 67, self.groundX, 1200, 130)
            self.ground.rotate_draw(rotation, 67, self.groundX-1200, 1200, 130)
#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class ItemManager:
    global ItemList, stageNum
    def __init__(self):
        self.x = 1500
    def SetStageItem(self):
        for i in range(30):
            if stageNum == 1:
                ItemList.append(Item((i*250)+random.randint(-250,250)+1200, random.randint(200,300), random.randint(1,4)))
            elif stageNum == 2:
                ItemList.append(Item((i*250)+random.randint(-250,250)+1200, random.randint(200,300), random.randint(1,4)))
            elif stageNum == 3:
                ItemList.append(Item(((-i)*250)+random.randint(-250,250)-1200, random.randint(200,300), random.randint(1,4)))
            elif stageNum == 4:
                ItemList.append(Item(((-i)*250)+random.randint(-250,250)+1200, random.randint(200,300), random.randint(1,4)))
    def updata(self):
        pass

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Item:
    global stageNum
    global yellow
    global ItemList
    global life
    global rotation
    load = False
    OneItem = None
    TwoItem = None
    ThreeItem = None
    FourItem = None
    def __init__(self, x, y, itemType):
        self.itemX = x
        self.itemY = y
        self.frame = 0
        self.MaxFrame = 6
        self.type = itemType
        self.item = None
        self.imageX = 0
        self.imageY = 0
        self.width = 0
        self.height = 0
        self.LoadItemImage()
        self.SetItemImage()

    def LoadItemImage(self):
        if Item.load == False:
            Item.OneItem = load_image('item1.png')
            Item.TwoItem = load_image('item2.png')
            Item.ThreeItem = load_image('item3.png')
            Item.FourItem = load_image('item4.png')
            Item.load = True

    def SetItemImage(self):
        if self.type == 1:
            self.item = Item.OneItem
            self.MaxFrame = 10
            self.imageX = 67
            self.imageY = 59
            self.width = 67
            self.height = 59
        elif self.type == 2:
            self.item = Item.TwoItem
            self.MaxFrame = 4
            self.imageX = 84
            self.imageY = 45
            self.width = 84
            self.height = 45
        elif self.type == 3:
            self.item = Item.ThreeItem
            self.MaxFrame = 4
            self.imageX = 84
            self.imageY = 45
            self.width = 84
            self.height = 45
        elif self.type == 4:
            self.item = Item.FourItem
            self.MaxFrame = 4
            self.imageX = 84
            self.imageY = 45
            self.width = 84
            self.height = 45

    def hit(self):
        for item in ItemList:
            if stageNum == 1:
                if (yellow.yellowX+yellow.width/3) >= (item.itemX - item.width/4) and (yellow.yellowX-yellow.width/3) <= (item.itemX + item.width/4):
                    if (yellow.yellowY - yellow.height/3) <= (item.itemY + item.height/3) and (yellow.yellowY + yellow.height/3) >= (item.itemY - item.height/3):
                        ItemList.remove(item)
                        return True
            if stageNum == 2:
                if (600-yellow.yellowX+(yellow.height/3)) >= (item.itemX-(item.width/2)) and (600-yellow.yellowX-(yellow.height/3)) <= (item.itemX+(item.width/2)):
                    if (1200-yellow.yellowY+(yellow.width/2)) >= (1200-item.itemY-(item.height/2)) and (1200-yellow.yellowY-(yellow.width/2)) <= (1200-item.itemY+(item.height/2)):
                        ItemList.remove(item)
                        return True
            if stageNum == 3:
                if (1200-yellow.yellowX+(yellow.width/3)) >= (item.itemX-(item.width/2)) and (1200-yellow.yellowX-(yellow.width/3)) <= (item.itemX+(item.width/2)):
                    if (800-yellow.yellowY-(yellow.height/2)) <= (800-item.itemY+(item.height/2)) and (800-yellow.yellowY+(yellow.height/2)) >= (800-item.itemY-(item.height/2)):
                        ItemList.remove(item)
                        return True
            if stageNum == 4:
                if (yellow.yellowX+200+(yellow.height/3)) >= (item.itemX+200-(item.width/2)) and (yellow.yellowX+200-(yellow.height/3)) <= (item.itemX+200+(item.width/2)):
                    if (yellow.yellowY+(yellow.width/2)) >= (item.itemY-(item.height/2)) and (yellow.yellowY-(yellow.width/2)) <= (item.itemY+(item.height/2)):
                        ItemList.remove(item)
                        return True
        return False

    def removeItem(self):
        for item in ItemList:
            if self.itemX <= -50:
                ItemList.remove(item)



    def update(self):
        self.frame = (self.frame+1) % self.MaxFrame
        self.moving()
        #self.removeItem()

    def moving(self):
        if stageNum == 1:
            self.itemX = (self.itemX-yellow.speed)
        elif stageNum == 2:
            self.itemX = (self.itemX-yellow.speed)
        elif stageNum == 3:
            self.itemX = (self.itemX+yellow.speed)
        elif stageNum == 4:
            self.itemX = (self.itemX+yellow.speed)


        if self.hit() == True:
            if self.type == 1:
                life.onelife += 5
            elif self.type == 2 or self.type == 3:
                life.onelife += 4

    def draw(self):
        if stageNum == 1:
            self.item.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.itemX, self.itemY, self.width, self.height)
            #draw_rectangle(self.itemX-(self.width/2),self.itemY-(self.height/2),self.itemX+(self.width/2), self.itemY+(self.height/2))
        elif stageNum == 2:
            self.item.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, 1200-self.itemY, self.itemX, self.width, self.height)
            #draw_rectangle(1200-self.itemY-(self.height/2),self.itemX-(self.width/2),1200-self.itemY+(self.height/2), self.itemX+(self.width/2))
        elif stageNum == 3:
            self.item.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.itemX, 800-self.itemY, self.width, self.height)
            #draw_rectangle(self.itemX-(self.width/2),800-self.itemY-(self.height/2),self.itemX+(self.width/2), 800-self.itemY+(self.height/2))
        elif stageNum == 4:
            self.item.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.itemY, self.itemX+200, self.width, self.height)
            #draw_rectangle(self.itemY-(self.height/2),self.itemX+200-(self.width/2),self.itemY+(self.height/2), self.itemX+200+(self.width/2))


#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class TrapManager:
    global TrapList, stageNum
    def __init__(self):
        self.x = 1500
    def SetStageTrap(self):
        for i in range(30):
            if stageNum == 1:
                TrapList.append(Trap((i*750)+random.randint(-250,250)+1200, random.randint(1,3)))
            if stageNum == 2:
                TrapList.append(Trap((i*750)+random.randint(-250,250)+1200, random.randint(1,3)))
            if stageNum == 3:
                TrapList.append(Trap(((-i)*750)+random.randint(-250,250)-1200, random.randint(1,3)))
            if stageNum == 4:
                TrapList.append(Trap(((-i)*750)+random.randint(-250,250)+1200, random.randint(1,3)))
    def updata(self):
        pass

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Trap:
    global stageNum
    global yellow
    global TrapList
    global life
    global rotation
    load = False
    firstStageOneTrap = None
    firstStageTwoTrap = None
    firstStageThreeTrap = None
    firstStageFourTrap = None
    SecondStageOneTrap = None
    SecondStageTwoTrap = None
    SecondStageThreeTrap = None
    SecondStageFourTrap = None
    ThirdStageOneTrap = None
    ThirdStageTwoTrap = None
    ThirdStageThreeTrap = None
    ThirdStageFourTrap = None
    FourthStageOneTrap = None
    FourthStageTwoTrap = None
    FourthStageThreeTrap = None
    FourthStageFourTrap = None
    def __init__(self, x, trapType):
        self.trapX = x   #?????????怨쀫엥???????????猷맣????節딄킅????x?????????釉랁닑???????????????????븐뼐?????????
        self.trapY = 0   #?????????怨쀫엥???????????猷맣????節딄킅????y?????????釉랁닑???????????????????븐뼐?????????
        self.frame = 0
        self.MaxFrame = 6
        self.type = trapType
        self.trap = None
        self.imageX = 0  #??????????椰??????? ???????????????????釉먮폁??????????怨뚮뼺?源껊??????
        self.imageY = 0  #??????????椰??????? ???????嫄??????????????????紐?????????
        self.width = 0
        self.height = 0
        self.LoadTrapImage()
        self.SetTrapImage()

    def LoadTrapImage(self):
        if Trap.load == False:
            Trap.firstStageOneTrap = load_image('1.1Trap.png')
            Trap.firstStageTwoTrap = load_image('1.2Trap.png')
            Trap.firstStageThreeTrap = load_image('1.3Trap.png')
            Trap.firstStageFourTrap = None
            Trap.SecondStageOneTrap = load_image('2.1Trap.png')
            Trap.SecondStageTwoTrap = load_image('2.2Trap.png')
            Trap.SecondStageThreeTrap = load_image('2.3Trap.png')
            Trap.SecondStageFourTrap = None
            Trap.ThirdStageOneTrap = load_image('3.1Trap.png')
            Trap.ThirdStageTwoTrap = load_image('3.2Trap.png')
            Trap.ThirdStageThreeTrap = load_image('3.3Trap.png')
            Trap.ThirdStageFourTrap = None
            Trap.FourthStageOneTrap = load_image('4.1Trap.png')
            Trap.FourthStageTwoTrap = load_image('4.2Trap.png')
            Trap.FourthStageThreeTrap = load_image('4.3Trap.png')
            Trap.FourthStageFourTrap = None
            Trap.load = True
            print('loadtrap')

    def SetTrapImage(self):
        if stageNum == 1:
            if self.type == 1:
                self.trap = Trap.firstStageOneTrap
                self.MaxFrame = 6
                self.imageX = 141
                self.imageY = 141
                self.trapY = 185
                self.width = 70
                self.height = 100
            elif self.type == 2:
                self.trap = Trap.firstStageTwoTrap
                self.MaxFrame = 6
                self.imageX = 133
                self.imageY = 148
                self.trapY = 195
                self.width = 100
                self.height = 135
            elif self.type == 3:
                self.trap = Trap.firstStageThreeTrap
                self.MaxFrame = 4
                self.imageX = 147
                self.imageY = 108
                self.trapY = 300
                self.width = 108
                self.height = 180
        if stageNum == 2:
            if self.type == 1:
                self.trap = Trap.SecondStageOneTrap
                self.MaxFrame = 10
                self.imageX = 84
                self.imageY = 78
                self.trapY = 180
                self.width = 100
                self.height = 100
            elif self.type == 2:
                self.trap = Trap.SecondStageTwoTrap
                self.MaxFrame = 10
                self.imageX = 110
                self.imageY = 135
                self.trapY = 210
                self.width = 100
                self.height = 200
            elif self.type == 3:
                self.trap = Trap.SecondStageThreeTrap
                self.MaxFrame = 12
                self.imageX = 173
                self.imageY = 136
                self.trapY = 415
                self.width = 173
                self.height = 400
        if stageNum == 3:
            if self.type == 1:
                self.trap = Trap.ThirdStageOneTrap
                self.MaxFrame = 6
                self.imageX = 97
                self.imageY = 149
                self.trapY = 180
                self.width= 130
                self.height = 100
            elif self.type == 2:
                self.trap = Trap.ThirdStageTwoTrap
                self.MaxFrame = 10
                self.imageX = 110
                self.imageY = 135
                self.trapY = 210
                self.width = 100
                self.height = 200
            elif self.type == 3:
                self.trap = Trap.ThirdStageThreeTrap
                self.MaxFrame = 12
                self.imageX = 86
                self.imageY = 165
                self.trapY = 490
                self.width = 120
                self.height = 610
        if stageNum == 4:
            if self.type == 1:
                self.trap = Trap.FourthStageOneTrap
                self.MaxFrame = 11
                self.imageX = 62
                self.imageY = 159
                self.trapY = 220
                self.width = 62
                self.height = 200
            elif self.type == 2:
                self.trap = Trap.FourthStageTwoTrap
                self.MaxFrame = 12
                self.imageX = 221
                self.imageY = 319
                self.trapY = 490
                self.width = 221
                self.height = 620
            elif self.type == 3:
                self.trap = Trap.FourthStageThreeTrap
                self.MaxFrame = 6
                self.imageX = 97
                self.imageY = 149
                self.trapY = 400
                self.width = 200
                self.height = 400


    def hit(self):
        for i in range(30):
            if stageNum == 1:
                if (yellow.yellowX+yellow.width/3) >= (TrapList[i].trapX - TrapList[i].width/4) and (yellow.yellowX-yellow.width/3) <= (TrapList[i].trapX + TrapList[i].width/4):
                    if TrapList[i].type == 1 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
                        return True
                    if TrapList[i].type == 2 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
                        return True
                    if TrapList[i].type == 3 and (yellow.yellowY - yellow.height/2) <= (TrapList[i].trapY + TrapList[i].height/2) and (yellow.yellowY + yellow.height/2) >= (TrapList[i].trapY - TrapList[i].height/2):
                        return True
            if stageNum == 2:
                if (600-yellow.yellowX+(yellow.height/3)) >= (TrapList[i].trapX-(TrapList[i].width/2)) and (600-yellow.yellowX-(yellow.height/3)) <= (TrapList[i].trapX+(TrapList[i].width/2)):
                    if (1200-yellow.yellowY+(yellow.width/2)) >= (1200-TrapList[i].trapY-(TrapList[i].height/2)) and (1200-yellow.yellowY-(yellow.width/2)) <= (1200-TrapList[i].trapY+(TrapList[i].height/2)):
                        return True
##                    if TrapList[i].type == 1 and (yellow.yellowX - yellow.height/2) <= (TrapList[i].trapY + TrapList[i].height/2) and (yellow.yellowX + yellow.height/2) >= (TrapList[i].trapY - TrapList[i].height/2):
##                        return True
##                    if TrapList[i].type == 2 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
##                        return True
##                    if TrapList[i].type == 3 and (yellow.yellowY - yellow.height/2) <= (TrapList[i].trapY + TrapList[i].height/2) and (yellow.yellowY + yellow.height/2) >= (TrapList[i].trapY - TrapList[i].height/2):

            if stageNum == 3:
                if (1200-yellow.yellowX+(yellow.width/3)) >= (TrapList[i].trapX-(TrapList[i].width/2)) and (1200-yellow.yellowX-(yellow.width/3)) <= (TrapList[i].trapX+(TrapList[i].width/2)):
                    if (800-yellow.yellowY-(yellow.height/2)) <= (800-TrapList[i].trapY+(TrapList[i].height/2)) and (800-yellow.yellowY+(yellow.height/2)) >= (800-TrapList[i].trapY-(TrapList[i].height/2)):
                        return True
##                    if TrapList[i].type == 1 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
##                        return True
##                    if TrapList[i].type == 2 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
##                        return True
##                    if TrapList[i].type == 3 and (yellow.yellowY - yellow.height/2) <= (TrapList[i].trapY + TrapList[i].height/2) and (yellow.yellowY + yellow.height/2) >= (TrapList[i].trapY - TrapList[i].height/2):

            if stageNum == 4:
                if (yellow.yellowX+200+(yellow.height/3)) >= (TrapList[i].trapX+200-(TrapList[i].width/2)) and (yellow.yellowX+200-(yellow.height/3)) <= (TrapList[i].trapX+200+(TrapList[i].width/2)):
                    if (yellow.yellowY+(yellow.width/2)) >= (TrapList[i].trapY-(TrapList[i].height/2)) and (yellow.yellowY-(yellow.width/2)) <= (TrapList[i].trapY+(TrapList[i].height/2)):
                        return True
##                    if TrapList[i].type == 1 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
##                        return True
##                    if TrapList[i].type == 2 and (yellow.yellowY - yellow.height/3) <= (TrapList[i].trapY + TrapList[i].height/3) and (yellow.yellowY + yellow.height/3) >= (TrapList[i].trapY - TrapList[i].height/3):
##                        return True
##                    if TrapList[i].type == 3 and (yellow.yellowY - yellow.height/2) <= (TrapList[i].trapY + TrapList[i].height/2) and (yellow.yellowY + yellow.height/2) >= (TrapList[i].trapY - TrapList[i].height/2):

        return False

    def update(self):
        self.frame = (self.frame+1) % self.MaxFrame
        self.moving()

    def moving(self):
        if stageNum == 1:
            self.trapX = (self.trapX-yellow.speed)
        if stageNum == 2:
            self.trapX = (self.trapX-yellow.speed)
        if stageNum == 3:
            self.trapX = (self.trapX+yellow.speed)
        if stageNum == 4:
            self.trapX = (self.trapX+yellow.speed)


        if self.hit() == True and yellow.isExistBuff('good') == False:
            yellow.SetCharacterState(yellow.BUMP)
            life.onelife -= 2
            yellow.createBuff('good',0.5)

    def draw(self):
        if stageNum == 1:
            self.trap.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.trapX, self.trapY, self.width, self.height)
            #draw_rectangle(self.trapX-(self.width/2),self.trapY-(self.height/2),self.trapX+(self.width/2), self.trapY+(self.height/2))
        if stageNum == 2:
            self.trap.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, 1200-self.trapY, self.trapX, self.width, self.height)
            #draw_rectangle(1200-self.trapY-(self.height/2),self.trapX-(self.width/2),1200-self.trapY+(self.height/2), self.trapX+(self.width/2))
        if stageNum == 3:
            self.trap.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.trapX, 800-self.trapY, self.width, self.height)
            #draw_rectangle(self.trapX-(self.width/2),800-self.trapY-(self.height/2),self.trapX+(self.width/2), 800-self.trapY+(self.height/2))
        if stageNum == 4:
            self.trap.clip_rotate_draw(rotation, self.frame * self.imageX, 0, self.imageX, self.imageY, self.trapY, self.trapX+200, self.width, self.height)
            #draw_rectangle(self.trapY-(self.height/2),self.trapX+200-(self.width/2),self.trapY+(self.height/2), self.trapX+200+(self.width/2))

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Character:
    global rotation
    RUN, SLIDING, JUMP, BUMP = 0, 1, 2, 3
    def __init__(self):
        self.speed = 20
        self.yellowY = 175
        self.yellowYJumpRun = 175
        self.yellowYSilde = 165
        self.yellowX = 400
        self.frame = 0
        self.character = load_image('YlarvaRun.png')
        self.runningCharacter = None
        self.slidingCharacter = None
        self.jumpingCharacter = None
        self.bumpingCharacter = None
        self.gravitySpeed = 0
        self.state = self.RUN
        self.MaxFrame = 5
        self.width = 90
        self.height = 90
        self.heightJumpRun = 90
        self.heightSlide = 70
        self.lastAnimateTime = get_time()
        self.buffList = []
        self.jumpNum = 0

    def gravity(self):
        if (self.yellowY-(self.height/2)-self.gravitySpeed) > 130:
            self.gravitySpeed += 7
            self.yellowY -=self.gravitySpeed
        else:
            #if self.state != self.SLIDING:
            self.yellowY = 130 + (self.height/2)
            self.gravitySpeed = 0

    def createBuff(self,name,remainTime):
        self.buffList.append( buff(name, remainTime) )
        if( name == 'booster'):
            self.speed += 50
    def isExistBuff(self,name):
        for buff in self.buffList:
            if( buff.name == name ):
                return True
        return False
    def deleteTimeoverBuff(self):
        for buff in self.buffList:
            if( buff.remainTime <= 0 ):
                self.removeBuff(buff)
    def removeBuff(self,buff):
        if( buff.name == 'booster'):
            self.speed -= 50
        self.buffList.remove(buff)

    def LoadCharacterImage(self):
        self.runningCharacter = load_image('YlarvaRun.png')
        self.slidingCharacter = load_image('YlarvaSlide.png')
        self.jumpingCharacter = load_image('YlarvaJump.png')
        self.bumpingCharacter = load_image('YlarvaBump.png')
        print('loadchar')

    def SetCharacterImage(self):
        self.frame = 0
        self.lastAnimateTime = get_time()
        if self.state == self.RUN:
            self.character = self.runningCharacter
            self.MaxFrame = 5
        elif self.state == self.SLIDING:
            self.character = self.slidingCharacter
            self.MaxFrame = 6
        elif self.state == self.JUMP:
            self.character = self.jumpingCharacter
            self.MaxFrame = 7
        elif self.state == self.BUMP:
            self.character = self.bumpingCharacter
            self.MaxFrame = 5

    def SetCharacterState(self, state):
        if state != self.state:
            if state == self.BUMP:
                self.state = self.BUMP
            elif state == self.RUN:
                self.state = self.RUN
            elif state == self.SLIDING:
                self.state = self.SLIDING
            elif state == self.JUMP:
                self.state = self.JUMP
            self.SetCharacterImage()

    def animate(self):
        if get_time() - self.lastAnimateTime > 0.05:
            self.lastAnimateTime = get_time()
            self.frame = (self.frame + 1)
            if (self.state == self.BUMP) and (self.frame >= self.MaxFrame):
                self.SetCharacterState(self.RUN)
            if (self.state != self.BUMP):
                self.frame = self.frame % self.MaxFrame
    def jumpCount(self):
        self.jumpNum += 1
        if (self.yellowY-(self.height/2)) == 130:
            self.jumpNum = 0
    def jumpToRun(self):
        if (self.state == self.JUMP) and (self.yellowY-(self.height/2)) == 130:
            yellow.SetCharacterState(yellow.RUN)

    def update(self):
        self.animate()
        self.gravity()
        self.jumpToRun()
        #buff
        for buff in self.buffList:
            buff.update()
        self.deleteTimeoverBuff()

    def draw(self):
        if stageNum == 1:
            self.character.clip_rotate_draw(rotation, self.frame * 90, 0, self.width, self.height, self.yellowX, self.yellowY, self.width, self.height)
            #draw_rectangle(self.yellowX-(self.width/3),self.yellowY-(self.height/2),self.yellowX+(self.width/3), self.yellowY+(self.height/2))
        if stageNum == 2:
            self.character.clip_rotate_draw(rotation, self.frame * 90, 0, self.width, self.height, 1200-self.yellowY, 600-self.yellowX, self.width, self.height)
            #draw_rectangle(1200-self.yellowY-(self.width/2),600-self.yellowX-(self.height/3),1200-self.yellowY+(self.width/2), 600-self.yellowX+(self.height/3))
        if stageNum == 3:
            self.character.clip_rotate_draw(rotation, self.frame * 90, 0, self.width, self.height, 1200-self.yellowX, 800-self.yellowY, self.width, self.height)
            #draw_rectangle(1200-self.yellowX-(self.width/3),800-self.yellowY-(self.height/2),1200-self.yellowX+(self.width/3), 800-self.yellowY+(self.height/2))
        if stageNum == 4:
            self.character.clip_rotate_draw(rotation, self.frame * 90, 0, self.width, self.height, self.yellowY, self.yellowX+200, self.width, self.height)
            #draw_rectangle(self.yellowY-(self.width/2),self.yellowX+200-(self.height/3),self.yellowY+(self.width/2), self.yellowX+200+(self.height/3))

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class buff():
    def __init__(self, name, remainTime):
        self.name = name
        self.remainTime = remainTime
        self.lastTime = get_time()
    def update(self):
        if( get_time() - self.lastTime > 0.1 ):
            self.lastTime = get_time()
            self.remainTime -= 0.1

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Life():
    def __init__(self, maxlife, onelife):
        self.maxlife = maxlife
        self.onelife = onelife
        self.maxLifeBar = None
        self.oneLifeBar = None
        self.barValue = (self.onelife/self.maxlife)*(500/10)
    def LoadLifeImage(self):
        self.maxLifeBar = load_image('maxLifeBar.png')
        self.oneLifeBar = load_image('oneLifeBar.png')
    def SetLifeBar(self):
        self.barValue = (self.onelife/self.maxlife)*(500/10)
    def update(self):
        self.onelife -= 0.2
    def draw(self):
        self.maxLifeBar.draw(300, 720, 506, 56)
        for i in range(int(self.barValue)):
            self.oneLifeBar.draw(55+i*10, 720, 10, 50)




#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
def enter():
    global yellow, stage, trapManager, stageNum, frame, life, TrapList, itemManager
    stage = Map()
    stage.LoadStageImage()
    stage.SetStageImage()
    life = Life(100, 100)
    life.LoadLifeImage()
    yellow = Character()
    yellow.LoadCharacterImage()
    trapManager = TrapManager()
    trapManager.SetStageTrap()
    itemManager = ItemManager()
    itemManager.SetStageItem()
    show_cursor()
    frame = 0
    stageNum = 1

def exit():
    global yellow, stage, trapManager, life, itemManager, item, trap
    del(stage)
    del(yellow)
    del(trapManager)
    del(itemManager)
    del(life)
    for trap in TrapList:
        del(trap)
    for item in ItemList:
        del(item)


def pause():
    pass

def resume():
    global stage, stageNum, rotation, life
    stageNum = 1
    stage.bkframe = 0
    stage.doubleX = 600
    stage.doubleY = 400
    stage.groundX = 600
    stage.groundY = 0
    stage.groundH = 0
    rotation = 0
    life.onelife = 100
    stage.SetStageImage()

def handle_events(frame_time):
    global yellow
    global stageNum
    global rotation
    global stage
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
             LarvaRun_Framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_UP:
                yellow.jumpCount()
                if 0 <= yellow.jumpNum <= 1:
                    yellow.gravitySpeed = -50
                yellow.SetCharacterState(yellow.JUMP)
            if event.key == SDLK_DOWN:
                if (yellow.yellowY-(yellow.height/2)) == 130:
                    yellow.gravitySpeed = 0
                    yellow.yellowY = yellow.yellowYSilde
                    yellow.height = yellow.heightSlide
                    yellow.SetCharacterState(yellow.SLIDING)
            elif event.key == SDLK_ESCAPE:
                LarvaRun_Framework.quit()
            elif event.key == SDLK_SPACE:
                yellow.createBuff('booster',2)
            elif event.key == SDLK_b:
                rotation += 1.5707963267948966
                stageNum += 1
                if stageNum == 5:
                    stageNum = 1
                if stageNum == 1 or stageNum == 3:
                    stage.doubleX, stage.groundX = 600,600
                if stageNum == 2 or stageNum == 4:
                    stage.doubleX, stage.groundX = 400,400
                stage.SetStageImage()
                TrapList.clear()
                trapManager.SetStageTrap()
                ItemList.clear()
                itemManager.SetStageItem()
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_DOWN:
                if (yellow.yellowY-(yellow.height/2)) == 130:
                    yellow.yellowY = yellow.yellowYJumpRun
                    yellow.height = yellow.heightJumpRun
                    yellow.SetCharacterState(yellow.RUN)

def update(frame_time):
    global yellow, stage, trap, life, item, rotation, stageNum
    stage.update()
    for trap in TrapList:
        trap.update()
    for item in ItemList:
        item.update()
    yellow.update()
    if life.onelife <= 0:
        life.onelife = 100
        LarvaRun_Framework.push_state(LarvaRunRank_state)
    life.update()
    life.SetLifeBar()
##
    delay(0.02)

def draw(frame_time):
    global yellow, stage, trap, life, item
    clear_canvas()
    stage.draw()
    for trap in TrapList:
        trap.draw()
    for item in ItemList:
        item.draw()
    life.draw()
    yellow.draw()
    update_canvas()
