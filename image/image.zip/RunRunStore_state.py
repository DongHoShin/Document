import LarvaRun_Framework
import LarvaRunTitle_state
from pico2d import *

name = "StoreState"
storeImage = None
backImage = None
MouseX, MouseY = 0,0
frame = 0
page = 1
startTime = 0.0
class Store():

    CHARACTER, PET, ITEM = 0, 1, 2

    def __init__(self):
        self.mainstoreImage = None
        self.petsImage = None
        self.larvaImage = None
        self.itemImage = None
        self.rightButton = None
        self.leftButton = None
        self.state = self.PET

    def LoadStoreImage(self):
        self.backImage = load_image('BackIcon.png')
        self.characterImage = load_image('shop2.png')
        self.petsImage = load_image('shop1.png')
        self.itemImage = load_image('shop3.png')
        self.rightButton = load_image('StoreButtonRight.png')
        self.leftButton = load_image('StoreButtonLeft.png')

    def SetStoreImage(self):
        if self.state == self.CHARACTER:
            self.mainstoreImage = self.characterImage
        elif self.state == self.PET:
            self.mainstoreImage = self.petsImage
        elif self.state == self.ITEM:
            self.mainstoreImage = self.itemImage
    def SetStoreState(self, state):
        if state != self.state:
            if state == self.CHARACTER:
                self.state = self.CHARACTER
            elif state == self.PET:
                self.state = self.PET
            elif state == self.ITEM:
                self.state = self.ITEM
            self.SetStoreImage()
    def update(self):
        self.SetStoreImage()
    def draw(self):
        self.mainstoreImage.draw(500, 400, 1000, 600)
        self.rightButton.draw(920, 600, 80, 80)
        self.leftButton.draw(850, 600, 80, 80)


class AnimationObject():
    RUN_SPEED_KMPH = 20.0                   # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)

    TIME_PER_ACTION = 0.8
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    def __init__(self, width, height, MaxFrame, image):
        self.x = 0
        self.y = 0
        self.width = width
        self.height = height
        self.MaxFrame = MaxFrame
        self.image = image
        self.frame = 0
        self.total_frames = 0.0
        self.holdTime =0.0
        self.newTime = 0.0
    def update(self, frame_time):
        self.newTime =  get_time()-(self.holdTime + startTime)
        self.total_frames += AnimationObject.FRAMES_PER_ACTION * AnimationObject.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % self.MaxFrame
    def draw(self):
        self.image.clip_draw(self.frame* self.width, 0, self.width, self.height, self.x, self.y)
    def setPos(self,x,y):
        self.x = x
        self.y = y+50

class StoreCard():
    global PetList
    def __init__(self, image, animationObject):
        self.x = 0
        self.y = 0
        self.image = image
        self.animationObject = animationObject
    def update(self, frame_time):
        self.animationObject.update(frame_time)
        self.animationObject.setPos(self.x,self.y)
    def draw(self):
        self.image.draw(self.x,self.y, 240, 420)
        self.animationObject.draw()
    def setPos(self,x,y):
        self.x = x
        self.y = y
#/////////////////////////////////////////////////////////////////////////////////////
class ShopIcons:
    RUN_SPEED_KMPH = 40.0                   # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)

    TIME_PER_ACTION = 0.8
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    def __init__(self, name, maxFrame, imageX, imageY, width, height, image, sizeX, sizeY):
        self.name = name
        self.maxFrame = maxFrame
        self.frame = 0
        self.imageX = imageX
        self.imageY = imageY
        self.width = width
        self.height =height
        self.sizeX = sizeX
        self.sizeY = sizeY
        self.dir = 1
        self.image = image
        self.total_frames = 0.0
        self.holdTime =0.0
        self.newTime = 0.0
    def update(self, frame_time):
        self.newTime =  get_time()-(self.holdTime + startTime)
        self.total_frames += ShopIcons.FRAMES_PER_ACTION * ShopIcons.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % self.maxFrame
    def draw(self):
        self.image.clip_draw(self.frame * self.width, 0, self.width, self.height, self.imageX, self.imageY, self.sizeX, self.sizeY)

#/////////////////////////////////////////////////////////////////////////////////////
def enter():
    global storeImage, backImage, store, animationObjectList, cardList, backIcon
    storeImage = load_image('shop.png')
    backImage = load_image('Backicon.png')
    store = Store()
    store.LoadStoreImage()

    cardList = []
    animationObjectList = []

    animationObjectList.append( AnimationObject(66,94,6,load_image('pet1.png')) )
    animationObjectList.append( AnimationObject(54,62,6,load_image('pet2.png')) )
    animationObjectList.append( AnimationObject(106,92,8,load_image('pet3.png')) )
    animationObjectList.append( AnimationObject(196,46,8,load_image('pet4.png')) )
    animationObjectList.append( AnimationObject(144,63,11,load_image('pet5.png')) )
    animationObjectList.append( AnimationObject(65,96,6,load_image('pet6.png')) )
    animationObjectList.append( AnimationObject(126,164,5,load_image('pet7.png')) )
    animationObjectList.append( AnimationObject(63,45,8,load_image('pet8.png')) )
    animationObjectList.append( AnimationObject(90,90,5,load_image('RlarvaRun.png')) )
    for i in range(8):
        directory = "petCard%d.png"%(i+1)
        cardList.append( StoreCard(load_image(directory),animationObjectList[i]) )
    cardList.append(StoreCard(load_image('characterCard1.png'),animationObjectList[8]))
    backIcon = ShopIcons('back', 10, 50, 750, 66, 44, backImage, 100, 80)


def exit():
    global storeImage, backImage, store, cardList,animationObjectList
    del(storeImage)
    del(backImage)
    del(store)
    del(cardList)
    del(animationObjectList)


def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    global MouseX, MouseY, store, page
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            LarvaRun_Framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                LarvaRun_Framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
                LarvaRun_Framework.push_state(LarvaRunMain_state)
            elif event.type == SDL_MOUSEMOTION:
                MouseX,MouseY = event.x,800-event.y
            elif (event.type, event.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
                if (0<=MouseX<=200 and 700<=MouseY<=800):
                    LarvaRun_Framework.pop_state()
                elif (30 <=MouseX <= 155 and 550<=MouseY<=600):
                    store.SetStoreState(store.PET)
                elif (165 <=MouseX <= 290 and 550<=MouseY<=600):
                    store.SetStoreState(store.CHARACTER)
                elif (300 <=MouseX <= 425 and 550<=MouseY<=600):
                    store.SetStoreState(store.ITEM)
                elif (890 <=MouseX <= 940 and 570<=MouseY<=630):
                    if page == 1:
                        page = 2
                elif (830 <=MouseX <= 880 and 570<=MouseY<=630):
                    if page == 2:
                        page = 1

def update(frame_time):
    global frame, store, cardList, animationObjectList, backIcon
    backIcon.update(frame_time)
    store.update()
    for card in cardList:
        card.update(frame_time)
    #delay(0.1)


def draw(frame_time):
    global storeImage, backIcon, store, cardList, animationObjectList, page
    clear_canvas()
    storeImage.draw(600, 400, 1200, 800)
    backIcon.draw()
    store.draw()

    cnt = 0
    for card in cardList:
        card.setPos(140+(cnt*240), 340)
        cnt = (cnt + 1)%4
    if store.state == store.PET:
        if page == 1:
            for i in range(4):
                cardList[i].draw()
        if page == 2:
            for i in range(4):
                cardList[i+4].draw()
    if store.state == store.CHARACTER:
        cardList[8].draw()
    update_canvas()



