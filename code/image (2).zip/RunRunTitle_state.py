import RunRun_Framework
import RunRunMain_state
from pico2d import *

name = "TitleState"
titleImage = None
startImage = None
MouseX, MouseY = 0,0
startTime = 0.0


#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Icons:
    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 40.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 1.0
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    def __init__(self, name, maxFrame, imageX, imageY, width, height, image, sizeX, sizeY):
        self.name = name
        self.maxFrame = maxFrame
        self.frame = 0
        self.imageX = imageX
        self.imageY = imageY
        self.width = width
        self.height =height
        self.sizeX = sizeX
        self.sizeY = sizeY
        self.dir = 1
        self.image = image
        self.total_frames = 0.0
        self.holdTime =0.0
        self.newTime = 0.0
    def update(self, frame_time):
        self.newTime =  get_time()-(self.holdTime + startTime)
        self.total_frames += 20 * frame_time
        self.frame = int(self.total_frames) % self.maxFrame
    def draw(self):
        self.image.clip_draw(self.frame * self.width, 0, self.width, self.height, self.imageX, self.imageY, self.sizeX, self.sizeY)








#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
def enter():
    global titleImage, startImage, startIcon
    titleImage = load_image('Title2.png')
    startImage = load_image('StartIcon.png')

    startIcon = Icons('start', 7, 600, 550, 424, 109, startImage, 424, 109)



def exit():
    global titleImage, startImage
    del(titleImage)
    del(startImage)



def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    global MouseX, MouseY
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            RunRun_Framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                RunRun_Framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
                RunRun_Framework.push_state(RunRunMain_state)
            elif event.type == SDL_MOUSEMOTION:
                MouseX,MouseY = event.x,800-event.y
            elif (event.type, event.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
                if (500<=MouseX<=700 and 500<=MouseY<=600):
                    RunRun_Framework.push_state(RunRunMain_state)




def update(frame_time):
    global startIcon
    startIcon.update(frame_time)



def draw(frame_time):
    global titleImage, startIcon
    global startFrame, howFrame
    clear_canvas()
    titleImage.draw(600, 400, 1200, 800)
    startIcon.draw()
    update_canvas()

