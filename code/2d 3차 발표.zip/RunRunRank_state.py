import RunRun_Framework
import RunRunMain_state
from pico2d import *


name = "RankState"
RankImage = None
MouseX, MouseY = 0,0
backImage = None
frame = 0

def enter():
    global RankImage, backImage
    RankImage = load_image('Rank.png')
    backImage = load_image('BackIcon.png')


def exit():
    global RankImage, backImage
    del(RankImage)
    del(backImage)

def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    global MouseX, MouseY
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            RunRun_Framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                RunRun_Framework.quit()
            elif event.type == SDL_MOUSEMOTION:
                MouseX,MouseY = event.x,800-event.y
            elif (event.type, event.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
                if (0<=MouseX<=200 and 650<=MouseY<=800):
                    RunRun_Framework.pop_state()
                    RunRun_Framework.pop_state()


def update(frame_time):
    global frame
    frame = (frame+1) % 10

def draw(frame_time):
    global RankImage, backImage
    clear_canvas()
    RankImage.draw(600, 400, 1200, 800)
    backImage.clip_draw(frame * 66, 0, 66, 100, 50, 750, 100, 80)
    update_canvas()